Name-Avinash Kaur
Student_id-7695265


The code here makes a small web application useful for keeping track of food items in the fridge.